# Changelog
- 2017.8.16
    - Initial version for Magisk v13.5
- 2017.9.28
    - Update applets info to Magisk v14.1
    - Add OTA tips
